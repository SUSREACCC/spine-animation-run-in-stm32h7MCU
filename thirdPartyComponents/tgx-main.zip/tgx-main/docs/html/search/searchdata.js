var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvwxyz",
  1: "bghimrsv",
  2: "bcfimrstv",
  3: "bcdefghijlmnoprstuvwz",
  4: "abcdefghilmnprstuvwxyz",
  5: "dfi",
  6: "abes",
  7: "bcdelrst",
  8: "mt",
  9: "bitu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

