var searchData=
[
  ['getanchor_0',['getAnchor',['../structtgx_1_1_box2.html#a4c56f3a8e6f200502de433bd980b7f37',1,'tgx::Box2']]],
  ['getcrop_1',['getCrop',['../classtgx_1_1_image.html#a5fd91f6ec1804de22f1586867fcc6e61',1,'tgx::Image']]],
  ['getenclosedwithsameratioas_5ffixed_2',['getEnclosedWithSameRatioAs_fixed',['../structtgx_1_1_box2.html#a947fcae0bf64d3fd24a4bef7b518e1bb',1,'tgx::Box2']]],
  ['getenclosingwithsameratioas_5ffixed_3',['getEnclosingWithSameRatioAs_fixed',['../structtgx_1_1_box2.html#ad5c9c1640c15383fc7ce0de1438d1791',1,'tgx::Box2']]],
  ['getmodelmatrix_4',['getModelMatrix',['../classtgx_1_1_renderer3_d.html#a9375b386649b40e2de3c82492614e2a0',1,'tgx::Renderer3D']]],
  ['getmultopacity_5',['getMultOpacity',['../structtgx_1_1_r_g_b32.html#a3bbc8afe02b2223caa3ba9484bd5b66c',1,'tgx::RGB32::getMultOpacity()'],['../structtgx_1_1_r_g_b64.html#a3703d1e5b5c8142400a2e73afba3cdfb',1,'tgx::RGB64::getMultOpacity()']]],
  ['getnormalize_6',['getNormalize',['../structtgx_1_1_vec2.html#a57a5d8782f0e5a413742cf2964180d23',1,'tgx::Vec2::getNormalize()'],['../structtgx_1_1_vec3.html#a1e36a77477b01aa50c6c94832b079e66',1,'tgx::Vec3::getNormalize()'],['../structtgx_1_1_vec4.html#a8a9b09ed5ce746238ec9d1d93af9f3ef',1,'tgx::Vec4::getNormalize()']]],
  ['getnormalize_5ffast_7',['getNormalize_fast',['../structtgx_1_1_vec2.html#addbe419840182a652d3a19c082a9f69d',1,'tgx::Vec2::getNormalize_fast()'],['../structtgx_1_1_vec3.html#a02a0471ddeb0d6dc4c4ce1bbc44dce16',1,'tgx::Vec3::getNormalize_fast()'],['../structtgx_1_1_vec4.html#a0afaf65b44786d35a882cb1ed56bec83',1,'tgx::Vec4::getNormalize_fast()']]],
  ['getprojectionmatrix_8',['getProjectionMatrix',['../classtgx_1_1_renderer3_d.html#a5252a0e6323fe799a2d01aa27c53fd4c',1,'tgx::Renderer3D']]],
  ['getrotate90_9',['getRotate90',['../structtgx_1_1_vec2.html#a4430d7ddcf5e1b873629cea7cf47bc42',1,'tgx::Vec2']]],
  ['getsplit_5ffixed_10',['getSplit_fixed',['../structtgx_1_1_box2.html#add91ecc6069411b7f1fe6c27d26fe2af',1,'tgx::Box2']]],
  ['getviewmatrix_11',['getViewMatrix',['../classtgx_1_1_renderer3_d.html#a7c835852a899217db08a2ccd77d1e14e',1,'tgx::Renderer3D']]],
  ['gifplayframe_12',['GIFplayFrame',['../classtgx_1_1_image.html#afa3e95f25f3533ebc2e4d50041d98fc5',1,'tgx::Image']]]
];
